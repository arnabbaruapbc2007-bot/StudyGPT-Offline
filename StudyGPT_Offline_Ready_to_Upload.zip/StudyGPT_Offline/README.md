# StudyGPT Offline — Android starter APK project

This is a phone-buildable, offline-first Android study helper MVP.

## Included
- Photo import and on-device OCR using the bundled ML Kit Latin text recognizer.
- PDF import: renders each page locally and OCRs it on-device.
- Study workspace with editable extracted text.
- Basic local arithmetic and one-variable linear-equation solving.
- Starter Physics, Mathematics and Chemistry formula library.
- Starter MCQ practice prompt.
- Local chat history stored in app preferences.
- Voice question entry using Android's speech recognition intent with offline preference.
- No app INTERNET permission.

## Important capability limits
This starter is **not a ChatGPT-class generative AI model**. It does not yet contain an LLM, so it cannot reliably solve arbitrary Physics, Chemistry, advanced Mathematics, diagrams, or generate high-quality adaptive MCQs. OCR reads text; it does not understand a diagram by itself. The voice feature asks the Android speech service to prefer offline recognition, but whether it works offline depends on the speech engine/language pack installed on the phone. The app itself has no internet permission.

For true open-ended offline AI, a compatible quantized model and a native inference runtime (for example llama.cpp) must be integrated and the model file supplied separately. Large models are not realistic on many Samsung A12 variants; start with a very small quantized model and expect slow inference and limited reasoning. Do not assume the app works like ChatGPT until that runtime/model has been added and tested.

## Build from a Samsung phone using GitHub
1. Download and extract `StudyGPT_Offline.zip` on your phone.
2. Open GitHub in Chrome and sign in.
3. Create a new repository named `StudyGPT-Offline`.
4. In the repository, choose **Add file → Upload files**. Upload the *contents* of this folder (including `.github`; enable “show hidden files” in your file manager if needed).
5. Commit the files to the `main` branch.
6. Open the repository's **Actions** tab. If GitHub asks, enable Actions.
7. Select **Build StudyGPT Offline APK** and tap **Run workflow**. You can also wait for the workflow to run after the first push.
8. Open the completed workflow run, scroll to **Artifacts**, and download `StudyGPT-Offline-debug-apk`.
9. Extract the downloaded artifact ZIP and tap `app-debug.apk` to install. If Android blocks it, allow Chrome or your file manager to install unknown apps only if you trust the APK you built.

## If the build fails
- Open the failed Actions run and inspect the first red error.
- Confirm that all project files, especially `.github/workflows/build.yml`, were uploaded.
- Ensure the repository root contains `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, and `app/`.
- Send the error screenshot or log for diagnosis.

## Privacy and data
- The app requests no camera, microphone, storage, or internet permission. Images and PDFs are selected through Android's document picker.
- OCR and PDF rendering run on-device.
- Conversation history is stored locally and can be cleared in the History tab.
- Android's speech recognition service is external to this app; offline behavior depends on the installed engine and downloaded language data.
