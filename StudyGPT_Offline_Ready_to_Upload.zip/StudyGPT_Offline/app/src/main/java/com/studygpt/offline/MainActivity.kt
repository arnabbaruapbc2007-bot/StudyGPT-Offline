package com.studygpt.offline

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudyGPTApp() }
    }
}

data class ChatLine(val question: String, val answer: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyGPTApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("studygpt", 0) }
    var input by remember { mutableStateOf("") }
    var extracted by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("Hello! Ask a question, take a photo, or open a PDF.") }
    var busy by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(0) }
    var history by remember {
        mutableStateOf(prefs.getString("history", "")!!.lines().filter { it.contains("|||") }
            .map { val p = it.split("|||", limit = 2); ChatLine(p[0], p[1]) }.reversed())
    }

    fun ask(q: String) {
        if (q.isBlank()) return
        val a = StudySolver.answer(q)
        output = a
        history = (listOf(ChatLine(q, a)) + history).take(80)
        prefs.edit().putString("history", history.reversed().joinToString("\n") { it.question.replace("\n"," ") + "|||" + it.answer.replace("\n"," ") }).apply()
        input = ""
    }

    fun runOcr(bitmap: Bitmap) {
        busy = true
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { result ->
                extracted = result.text
                input = result.text
                output = if (result.text.isBlank()) "No readable text found. Try a clearer, well-lit photo." else "I read this from your image. Check the transcription, then tap Solve.\n\n${result.text}"
                busy = false
                recognizer.close()
            }
            .addOnFailureListener {
                output = "Could not read the image: ${it.localizedMessage}"
                busy = false
                recognizer.close()
            }
    }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                val bmp = if (android.os.Build.VERSION.SDK_INT >= 28) {
                    val source = android.graphics.ImageDecoder.createSource(context.contentResolver, uri)
                    android.graphics.ImageDecoder.decodeBitmap(source) { decoder, _, _ -> decoder.isMutableRequired = true }
                } else {
                    @Suppress("DEPRECATION")
                    BitmapFactory.decodeStream(context.contentResolver.openInputStream(uri))!!
                }
                runOcr(bmp)
            } catch (e: Exception) { output = "Image error: ${e.localizedMessage}" }
        }
    }

    val pdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            busy = true
            try {
                val pfd = context.contentResolver.openFileDescriptor(uri, "r")
                if (pfd == null) { output = "Cannot open this PDF."; busy = false }
                else {
                    val renderer = PdfRenderer(pfd)
                    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                    val pages = (0 until renderer.pageCount).toList()
                    val collected = StringBuilder()
                    fun processPage(index: Int) {
                        if (index >= pages.size) {
                            extracted = collected.toString()
                            input = extracted
                            output = "PDF reading finished (${pages.size} pages). Review the extracted text, then tap Solve."
                            busy = false
                            recognizer.close()
                            renderer.close()
                            pfd.close()
                            return
                        }
                        val page = renderer.openPage(index)
                        val scale = (1200f / page.width).coerceAtMost(2f)
                        val bmp = Bitmap.createBitmap((page.width * scale).toInt().coerceAtLeast(1), (page.height * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        page.close()
                        recognizer.process(InputImage.fromBitmap(bmp, 0))
                            .addOnSuccessListener { collected.append("\n\n[Page ${index + 1}]\n").append(it.text); processPage(index + 1) }
                            .addOnFailureListener { collected.append("\n[Page ${index + 1}: OCR failed]\n"); processPage(index + 1) }
                    }
                    processPage(0)
                }
            } catch (e: Exception) { output = "PDF error: ${e.localizedMessage}"; busy = false }
        }
    }

    val voicePicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) input = spoken
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF3157D5))) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("StudyGPT Offline") }, actions = {
                IconButton(onClick = { tab = 1 }) { Icon(Icons.Default.History, "History") }
                IconButton(onClick = { tab = 2 }) { Icon(Icons.Default.MenuBook, "Formulas") }
            }) },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Chat, null) }, label = { Text("Study") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.History, null) }, label = { Text("History") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Functions, null) }, label = { Text("Formulas") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
                    Text("Offline study workspace", style = MaterialTheme.typography.titleMedium)
                    Text("No account • No app internet permission • Your study history stays on this device", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { photoPicker.launch("image/*") }, enabled = !busy) { Icon(Icons.Default.CameraAlt, null); Text(" Photo") }
                        OutlinedButton(onClick = { pdfPicker.launch(arrayOf("application/pdf")) }, enabled = !busy) { Icon(Icons.Default.PictureAsPdf, null); Text(" PDF") }
                        OutlinedButton(onClick = {
                            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Ask your study question")
                            }
                            try { voicePicker.launch(i) } catch (_: Exception) { output = "No speech recognition service is installed." }
                        }) { Icon(Icons.Default.Mic, null); Text(" Voice") }
                    }
                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 8.dp))
                    Card(Modifier.fillMaxWidth().weight(1f).padding(vertical = 10.dp)) {
                        Column(Modifier.verticalScroll(rememberScrollState()).padding(14.dp)) {
                            Text(output)
                        }
                    }
                    OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 90.dp, max = 170.dp), label = { Text("Type or edit your question") }, placeholder = { Text("Example: Solve 2x + 5 = 17 step by step") })
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { ask(input) }, modifier = Modifier.weight(1f), enabled = input.isNotBlank() && !busy) { Icon(Icons.Default.Send, null); Text(" Solve") }
                        OutlinedButton(onClick = { input = StudySolver.makeQuiz() }) { Icon(Icons.Default.Quiz, null); Text(" MCQ") }
                    }
                }
                1 -> Column(Modifier.padding(padding).padding(16.dp)) {
                    Text("Recent conversations", style = MaterialTheme.typography.titleLarge)
                    if (history.isEmpty()) Text("Your questions will appear here.")
                    LazyColumn {
                        items(history) { item ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), onClick = { input = item.question; output = item.answer; tab = 0 }) {
                                Column(Modifier.padding(12.dp)) { Text(item.question, style = MaterialTheme.typography.titleSmall); Text(item.answer.take(180), style = MaterialTheme.typography.bodySmall) }
                            }
                        }
                    }
                    TextButton(onClick = { history = emptyList(); prefs.edit().remove("history").apply() }) { Text("Clear history") }
                }
                else -> Column(Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(16.dp)) {
                    Text("Formula library", style = MaterialTheme.typography.titleLarge)
                    StudySolver.formulas.forEach { (topic, formula) ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                            Column(Modifier.padding(12.dp)) { Text(topic, style = MaterialTheme.typography.titleMedium); Text(formula) }
                        }
                    }
                }
            }
        }
    }
}
