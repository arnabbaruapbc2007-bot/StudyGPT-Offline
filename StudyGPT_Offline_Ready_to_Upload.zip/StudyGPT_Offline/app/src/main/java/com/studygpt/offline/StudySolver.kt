package com.studygpt.offline

import kotlin.math.*

object StudySolver {
    val formulas = listOf(
        "Physics • Motion" to "v = u + at\ns = ut + ½at²\nv² = u² + 2as",
        "Physics • Force & energy" to "F = ma\nW = Fs cosθ\nK = ½mv²\nP = W/t",
        "Physics • Electricity" to "V = IR\nP = VI = I²R = V²/R\nR(series) = R₁ + R₂ + …",
        "Physics • Waves" to "v = fλ\nT = 1/f",
        "Mathematics • Algebra" to "(a+b)² = a² + 2ab + b²\n(a-b)² = a² - 2ab + b²\na²-b² = (a-b)(a+b)",
        "Mathematics • Calculus" to "d(xⁿ)/dx = nxⁿ⁻¹\n∫xⁿ dx = xⁿ⁺¹/(n+1) + C (n ≠ -1)",
        "Mathematics • Trigonometry" to "sin²θ + cos²θ = 1\ntanθ = sinθ/cosθ\nsin(A±B) = sinA cosB ± cosA sinB",
        "Chemistry • Mole" to "n = mass / molar mass\nN = n × Nₐ\nPV = nRT",
        "Chemistry • Solutions" to "Molarity = moles of solute / volume (L)\nDilution: M₁V₁ = M₂V₂",
        "Chemistry • Electrochemistry" to "Q = It\nΔG = -nFE\nEcell = Ecathode - Eanode"
    )

    fun makeQuiz(): String = """Quick MCQ practice
1) SI unit of force?
A) Joule  B) Newton  C) Watt  D) Pascal
Answer: B) Newton

2) Derivative of x²?
A) x  B) 2x  C) x³  D) 2
Answer: B) 2x

3) Avogadro constant is approximately?
A) 6.022×10²³  B) 3×10⁸  C) 9.8  D) 1.6×10⁻¹⁹
Answer: A) 6.022×10²³

Use these as a starter quiz; question difficulty and answer checking are not adaptive yet."""

    fun answer(raw: String): String {
        val q = raw.trim()
        val lower = q.lowercase()
        val arithmetic = Regex("""^\s*(-?\d+(?:\.\d+)?)\s*([+\-*/])\s*(-?\d+(?:\.\d+)?)\s*=?\s*$""").matchEntire(q)
        if (arithmetic != null) {
            val a = arithmetic.groupValues[1].toDouble()
            val op = arithmetic.groupValues[2]
            val b = arithmetic.groupValues[3].toDouble()
            val result = when (op) {
                "+" -> a + b; "-" -> a - b; "*" -> a * b
                "/" -> if (b != 0.0) a / b else return "Division by zero is undefined."
                else -> Double.NaN
            }
            return "Step-by-step:\n1. Identify the operation: $a $op $b\n2. Substitute the values.\n3. Calculate.\nAnswer: $result"
        }
        val linear = Regex("""^\s*([+-]?\d*)\s*x\s*([+-]\s*\d+(?:\.\d+)?)?\s*=\s*([+-]?\d+(?:\.\d+)?)\s*$""", RegexOption.IGNORE_CASE).matchEntire(q)
        if (linear != null) {
            val coeffText = linear.groupValues[1]
            val a = when (coeffText) { "", "+" -> 1.0; "-" -> -1.0; else -> coeffText.toDoubleOrNull() ?: 1.0 }
            val b = linear.groupValues[2].replace(" ", "").toDoubleOrNull() ?: 0.0
            val c = linear.groupValues[3].toDouble()
            if (a == 0.0) return "The coefficient of x is zero; this is not a linear equation in x."
            val x = (c - b) / a
            return "Solve: $q\n\n1. Move the constant term to the right: ${a}x = ${c - b}\n2. Divide both sides by $a.\n3. x = ($c - $b) / $a\n\nAnswer: x = $x\n\nCheck by substituting x into the original equation."
        }
        val relevant = formulas.filter { (topic, _) ->
            val words = (topic + " " + lower).lowercase()
            when {
                lower.contains("newton") || lower.contains("force") -> topic.contains("Force")
                lower.contains("mole") || lower.contains("avogadro") -> topic.contains("Mole")
                lower.contains("electro") -> topic.contains("Electrochemistry")
                lower.contains("derivative") || lower.contains("integral") -> topic.contains("Calculus")
                lower.contains("trigon") || lower.contains("sin") -> topic.contains("Trigonometry")
                else -> false
            }
        }
        val formulaText = if (relevant.isNotEmpty()) "\n\nRelated formulas:\n" + relevant.joinToString("\n") { "${it.first}\n${it.second}" } else ""
        return """I can help organize this question, but this starter build does not contain a generative language model.

A good solution workflow:
1. Write down the given values and units.
2. Identify the topic and the relevant law or formula.
3. Rearrange the formula before substituting values.
4. Calculate carefully, keeping units.
5. Check dimensions and whether the result is reasonable.

For a full worked solution, include the exact question text and any diagram labels. I can currently solve simple arithmetic and one-variable linear equations locally; broader Physics, Chemistry and advanced Math reasoning needs an on-device language model/runtime.$formulaText"""
    }
}
